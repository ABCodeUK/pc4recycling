import EwcCodes from "@/Pages/Settings/Variables/EwcCodes/EwcCodes"; // Import the EWC Codes page

export default function Variables() {
    // Render the EWC Codes page directly
    return <EwcCodes ewcCodes={[]} />;
}
